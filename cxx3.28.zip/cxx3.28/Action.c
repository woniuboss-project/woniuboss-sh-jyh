Action()
{
	//��¼�Ľӿ�
	web_reg_save_param_json(
		"ParamName=result",
		"QueryString=$..error",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);

	lr_start_transaction("login");

	web_custom_request("login_request",
		"URL=https://snailpet.com/v2/Passport/login",
		"Method=post",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={login}",
		LAST);

	lr_output_message(lr_eval_string("{result}"));
	
	if ((lr_eval_string("{result}")) == 0){
		lr_output_message("login success");
		lr_end_transaction("login", LR_PASS);

	}else{
		lr_output_message("login fail");
		lr_end_transaction("login", LR_FAIL);
	}
	
	//���ӻ�Ա�Ľӿ�
	web_reg_save_param_json(
		"ParamName=customer",
		"QueryString=$..error",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);

	lr_start_transaction("customer_things");


	web_custom_request("add_cus",
		"URL=https://snailpet.com/v2/Members/add",
		"Method=post",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={add_customer}",
		LAST);

	lr_output_message(lr_eval_string("{customer}"));
	
	if ((lr_eval_string("{customer}")) == 0){
		lr_output_message("add success");

	}else{
		lr_output_message("add fail");
	}
	
	//ɸѡ��Ա�Ľӿ�
	web_reg_save_param_json(
		"ParamName=select_customers",
		"QueryString=$..error",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);
	web_custom_request("select_cus",
		"URL=https://snailpet.com/v2/analysis_es/action",
		"Method=post",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={select_customer}",
		LAST);

	lr_output_message(lr_eval_string("{select_customers}"));
	
	if ((lr_eval_string("{select_customers}")) == 0){
		lr_output_message("select success");
		lr_end_transaction("customer_things", LR_PASS);

	}else{
		lr_output_message("select fail");
		lr_end_transaction("customer_things", LR_FAIL);
	}
	
	//���ӻ�Ա���Ľӿ�
	web_reg_save_param_json(
		"ParamName=add_customer_card",
		"QueryString=$..error",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);
	lr_start_transaction("add_customer_cards");

	web_custom_request("web_custom_request",
		"URL=https://snailpet.com/v2/Shop/setMemberLevel",
		"Method=post",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"EncType=application/json",
		"Body={cutomercards}",
		LAST);

	lr_output_message(lr_eval_string("{add_customer_card}"));
	
	if ((lr_eval_string("{add_customer_card}")) == 0){
		lr_output_message("add card success");
		lr_end_transaction("add_customer_cards", LR_PASS);

	}else{
		lr_output_message("add card fail");
		lr_end_transaction("add_customer_cards", LR_FAIL);
	}
	
	//�����ο��ӿ�
	web_reg_save_param_json(
		"ParamName=add_customer_ second_card",
		"QueryString=$..error",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);
	lr_start_transaction("add_customer_ second_cards");

	web_submit_data("web_submit_data",
		"Action=https://snailpet.com/v2/Shop/addOnceCards",
		"Method=POST",
		"TargetFrame=",
		"Referer=",
		ITEMDATA,
		"Name=shopId", "Value=17555", ENDITEM,
		"Name=cardName", "Value=������ο�", ENDITEM,
		"Name=productId", "Value=2133822", ENDITEM,
		"Name=exp_time_type", "Value=0", ENDITEM,
		"Name=shop_id", "Value=17555", ENDITEM,
		LAST);

	lr_output_message(lr_eval_string("{add_customer_ second_card}"));
	
	if ((lr_eval_string("{add_customer_ second_card}")) == 0){
		lr_output_message("add second card success");
		lr_end_transaction("add_customer_ second_cards", LR_PASS);

	}else{
		lr_output_message("add secong card fail");
		lr_end_transaction("add_customer_ second_cards", LR_FAIL);
	}
	return 0;
}
